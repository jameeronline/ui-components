var allowedLocales = ["en", "ar", "ur"];
const url = new URL(location.href);
var currentLocale = new URLSearchParams(window.location.search).get('locale');
var requestLocale = currentLocale && allowedLocales.includes(currentLocale.toLowerCase()) ? currentLocale.toLowerCase() : "ar" ;
requestLocale = requestLocale.toLowerCase();
url.searchParams.set('locale', requestLocale);

//add locale to each action link
function manageLocalizationState() {
  [...Array.from(document.getElementsByClassName("locale-dirty"))].forEach((item, i) => {
    cURL = new URL(item.href);
    cURL.searchParams.set('locale', requestLocale);
    item.href = cURL ;
  });

  // inilialize i18next to put localized terms
  i18next.init({
    lng: requestLocale,
    debug: false,
    resources: {
      en: {
        translation: translatoin.en
      },
      ar: {
        translation: translatoin.ar
      },
      ur: {
        translation: translatoin.ur
      }
    }
  }, () => {
      document.body.querySelectorAll('[innerText-i18n]').forEach(element => {
          element.innerText = i18next.t(element.getAttribute('innerText-i18n'));
      });
    }
  );
}





directions = {
  ltr: ["en"],
  rtl: ["ar", "ur"]
}

const lngSwitcher = `<select id="langSwitcher" class="selectpicker" data-width="fit">
    <option value="en">English</option>
    <option value="ar">Arabic</option>
    <option value="ur">Urdu</option>
</select>` ;

document.getElementById("lngSwitcherPlaceHolder").innerHTML = lngSwitcher ;
document.getElementById("langSwitcher").value = requestLocale ;

document.getElementById("langSwitcher").addEventListener('change', function() {
  url.searchParams.set('locale', document.getElementById("langSwitcher").value);
  location.assign(url.search);
});


requiredDirection = directions.ltr.includes(requestLocale) ? "ltr" : "rtl" ;
document.getElementsByTagName('html')[0].setAttribute("dir", requiredDirection) ;
document.getElementsByTagName('html')[0].setAttribute("lang", requestLocale) ;
